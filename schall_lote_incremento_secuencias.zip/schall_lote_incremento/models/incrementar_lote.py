# - * - coding: utf-8 - * -
from odoo import _
from odoo import api
from odoo import fields
from odoo import models
from odoo import exceptions

class IncrementaLote(models.Model):
    _inherit = 'stock.move.line'

        
        
    @api.model
    def _crear_numero_lote(self):
        #El objeto self está vacío
        #se obtiene el id actual y se busca en stock.move
        active_id_ = self._context.get('active_id')
        rec = self.env['stock.move'].browse((active_id_))
        next_number=self.env['ir.sequence'].next_by_code('consecutivo.paca')
        #self.env['ir.sequence'].write({'valor':0})
        if rec.origin==False or rec.product_id.name== False:
            lote='LOTE-DEFAULT'
        else:
            lote=str(rec.origin+'/'+rec.product_id.name+'/'+next_number)
        print(lote)
        return lote

    @api.model
    def write(self):
        #Reinicia Secuencia
        secuencia = self.env['ir.sequence'].search([('code', '=','consecutivo.paca')])
        secuencia.number_next=(1)

    lot_name = fields.Char(default=_crear_numero_lote)
    

class ReiniciaSequencePicking(models.Model):
    _inherit = 'stock.picking'
     
    def view_init(self,self2=1):
        print('vista SHOWME PICKINGGG')
        secuencia = self.env['ir.sequence'].search([('code', '=','consecutivo.paca')])
        secuencia.number_next=(1)

#Reinicia cuando se confirma el pedido
class ReiniciaSequence(models.Model):
    _inherit = 'stock.move'
     
    def view_init(self,self2=1):
        print('vista SHOWME')
        secuencia = self.env['ir.sequence'].search([('code', '=','consecutivo.paca')])
        secuencia.number_next=(1)
